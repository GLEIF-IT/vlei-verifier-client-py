# vlei-verifier-client-py

Python client for vlei-verifier.

## Installation

```bash
pip install vlei-verifier-client